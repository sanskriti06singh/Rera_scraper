# RERA Odisha Scraper

A Python script to scrape the first 6 registered projects from the Odisha RERA website.

## 🔧 Requirements

Install dependencies using:

```
pip install -r requirements.txt
```

## 🚀 How to Run

```bash
python rera_scraper.py
```

## 📦 Extracted Fields

- RERA Regd. No
- Project Name
- Promoter Name
- Promoter Address
- GST No
