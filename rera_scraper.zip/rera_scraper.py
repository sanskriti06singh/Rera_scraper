from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager
from bs4 import BeautifulSoup
import time
import pandas as pd

def scrape_rera_odisha():
    options = Options()
    options.add_argument("--headless")
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()), options=options)

    url = "https://rera.odisha.gov.in/projects/project-list"
    driver.get(url)
    time.sleep(5)

    driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
    time.sleep(3)

    soup = BeautifulSoup(driver.page_source, "html.parser")

    project_links = []
    rows = driver.find_elements(By.CSS_SELECTOR, "table tbody tr")[:6]
    for row in rows:
        view_button = row.find_element(By.XPATH, ".//a[contains(text(),'View Details')]")
        project_links.append(view_button.get_attribute("href"))

    projects_data = []
    for link in project_links:
        driver.get(link)
        time.sleep(3)
        detail_soup = BeautifulSoup(driver.page_source, "html.parser")

        try:
            reg_no = detail_soup.find("label", string="RERA Registration No.").find_next("p").text.strip()
            proj_name = detail_soup.find("label", string="Project Name").find_next("p").text.strip()
        except AttributeError:
            continue

        try:
            promoter_tab = driver.find_element(By.LINK_TEXT, "Promoter Details")
            promoter_tab.click()
            time.sleep(2)
            promoter_soup = BeautifulSoup(driver.page_source, "html.parser")

            promoter_name = promoter_soup.find("label", string="Company Name").find_next("p").text.strip()
            address = promoter_soup.find("label", string="Registered Office Address").find_next("p").text.strip()
            gst = promoter_soup.find("label", string="GST No.").find_next("p").text.strip()
        except:
            promoter_name = address = gst = "N/A"

        projects_data.append({
            "RERA Regd. No": reg_no,
            "Project Name": proj_name,
            "Promoter Name": promoter_name,
            "Promoter Address": address,
            "GST No": gst
        })

    driver.quit()

    df = pd.DataFrame(projects_data)
    print(df)

if __name__ == "__main__":
    scrape_rera_odisha()
